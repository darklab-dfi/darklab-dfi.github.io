<template>
  <footer class="footer">
    <div class="container-fluid d-flex flex-wrap justify-content-between">
            PwC DarkLab Digital Footprint Intellligence Tool
      <div class="copyright d-flex flex-wrap">
        &copy; Developed by ISOM 4400 Group 3, The Hong Kong University of Science and Technology
      </div>
    </div>
  </footer>
</template>
<script>
export default {};
</script>
<style>
</style>

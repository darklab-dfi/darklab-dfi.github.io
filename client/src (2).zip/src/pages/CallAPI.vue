<template>
    <div class="row">
      <div class="text-left">
        <input 
          type="entityName" 
          name="entityName" 
          v-model="entityName"
          placeholder="Entity Name"/>
        <br>
        <br>
        <input 
          type="searchDomain" 
          name="searchDomain" 
          v-model="searchDomain"
          placeholder="Search domain"/>
        <br>
        <br>
        <input 
          type="keyword" 
          name="keyword" 
          v-model="keyword"
          placeholder="Keyword"/>
        <br>
        <br>
        <button
          type="info"
          round
          @click="getOutput">
          Search
        </button>
        <br>
        <br>
      
        <p class="text-info">
            OutS11
        </p>
        <div class="scroll">
          <table id="outS11" class='text_left'>
          <thead>
            <tr>
              <th v-for="(key_, index) in Object.keys(outS11[0])" :key="index">{{key_}}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, index) in outS11" :key="index">
              <td v-for="(key_, index) in Object.keys(outS11[0])" :key="index">{{row[key_]}}</td>
            </tr>
          </tbody>
          </table>
        </div>

        <p class="text-info">
                OutS12
        </p>
        <div class="scroll">
          <table id="outS12" class='text_left'>
          <thead>
            <tr>
              <th v-for="(key_, index) in Object.keys(outS12[0])" :key="index">{{key_}}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, index) in outS12" :key="index">
              <td v-for="(key_, index) in Object.keys(outS12[0])" :key="index">{{row[key_]}}</td>
            </tr>
          </tbody>
          </table>
        </div>

        <p class="text-info">
                OutS13
        </p>
        <div class="scroll">
          <table id="outS13" class='text_left'>
          <thead>
            <tr>
              <th v-for="(key_, index) in Object.keys(outS13[0])" :key="index">{{key_}}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, index) in outS13" :key="index">
              <td v-for="(key_, index) in Object.keys(outS13[0])" :key="index">{{row[key_]}}</td>
            </tr>
          </tbody>
          </table>
        </div>

        <p class="text-info">
                OutS14
        </p>
        <div class="scroll">
          <table id="outS14" class='text_left'>
          <thead>
            <tr>
              <th v-for="(key_, index) in Object.keys(outS14[0])" :key="index">{{key_}}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, index) in outS14" :key="index">
              <td v-for="(key_, index) in Object.keys(outS14[0])" :key="index">{{row[key_]}}</td>
            </tr>
          </tbody>
          </table>
        </div>

        <p class="text-info">
                OutS15
        </p>
        <div class="scroll">
          <table id="outS15" class='text_left'>
          <thead>
            <tr>
              <th v-for="(key_, index) in Object.keys(outS15[0])" :key="index">{{key_}}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, index) in outS15" :key="index">
              <td v-for="(key_, index) in Object.keys(outS15[0])" :key="index">{{row[key_]}}</td>
            </tr>
          </tbody>
          </table>
        </div>

        <p class="text-info">
                OutS16
        </p>
        <div class="scroll">
          <table id="outS16" class='text_left'>
          <thead>
            <tr>
              <th v-for="(key_, index) in Object.keys(outS16[0])" :key="index">{{key_}}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, index) in outS16" :key="index">
              <td v-for="(key_, index) in Object.keys(outS16[0])" :key="index">{{row[key_]}}</td>
            </tr>
          </tbody>
          </table>
        </div>

        <p class="text-info">
                OutS17
        </p>
        <div class="scroll">
          <table id="outS17" class='text_left'>
          <thead>
            <tr>
              <th v-for="(key_, index) in Object.keys(outS17[0])" :key="index">{{key_}}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, index) in outS17" :key="index">
              <td v-for="(key_, index) in Object.keys(outS17[0])" :key="index">{{row[key_]}}</td>
            </tr>
          </tbody>
          </table>
        </div>

        <p class="text-info">
                OutS18
        </p>
        <p>
                {{ outS18 }}
        </p>

        <p class="text-info">
                OutS19
        </p>
        <div class="scroll">
          <table id="outS19" class='text_left'>
          <thead>
            <tr>
              <th v-for="(key_, index) in Object.keys(outS19[0])" :key="index">{{key_}}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, index) in outS19" :key="index">
              <td v-for="(key_, index) in Object.keys(outS19[0])" :key="index">{{row[key_]}}</td>
            </tr>
          </tbody>
          </table>
        </div>

        <p class="text-info">
                OutS110
        </p>
        <div class="scroll">
          <table id="outS110" class='text_left'>
          <thead>
            <tr>
              <th v-for="(key_, index) in Object.keys(outS110[0])" :key="index">{{key_}}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, index) in outS110" :key="index">
              <td v-for="(key_, index) in Object.keys(outS110[0])" :key="index">{{row[key_]}}</td>
            </tr>
          </tbody>
          </table>
        </div>

        <p class="text-info">
                OutS20
        </p>
        <div class="scroll">
          <table id="outS20" class='text_left'>
          <thead>
            <tr>
              <th v-for="(key_, index) in Object.keys(outS20[0])" :key="index">{{key_}}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, index) in outS20" :key="index">
              <td v-for="(key_, index) in Object.keys(outS20[0])" :key="index">{{row[key_]}}</td>
            </tr>
          </tbody>
          </table>
        </div>

        <p class="text-info">
                OutS31
        </p>
        <div class="scroll">
          <table id="outS31" class='text_left'>
          <thead>
            <tr>
              <th v-for="(key_, index) in Object.keys(outS31[0])" :key="index">{{key_}}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, index) in outS31" :key="index">
              <td v-for="(key_, index) in Object.keys(outS31[0])" :key="index">{{row[key_]}}</td>
            </tr>
          </tbody>
          </table>
        </div>

        <p class="text-info">
                OutS32
        </p>
        <div class="scroll">
          <table id="outS32" class='text_left'>
          <thead>
            <tr>
              <th v-for="(key_, index) in Object.keys(outS32[0])" :key="index">{{key_}}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, index) in outS32" :key="index">
              <td v-for="(key_, index) in Object.keys(outS32[0])" :key="index">{{row[key_]}}</td>
            </tr>
          </tbody>
          </table>
        </div>

        <p class="text-info">
                outS33_dubiousFiles
        </p>
        <div class="scroll">
          <table id="outS33_dubiousFile" class='text_left'>
          <thead>
            <tr>
              <th v-for="(key_, index) in Object.keys(outS33_dubiousFile[0])" :key="index">{{key_}}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, index) in outS33_dubiousFile" :key="index">
              <td v-for="(key_, index) in Object.keys(outS33_dubiousFile[0])" :key="index">{{row[key_]}}</td>
            </tr>
          </tbody>
          </table>
        </div>

        <p class="text-info">
                outS33_failConnectedFiles
        </p>
        <div class="scroll">
          <table id="outS33_failConnected" class='text_left'>
          <thead>
            <tr>
              <th v-for="(key_, index) in Object.keys(outS33_failConnected[0])" :key="index">{{key_}}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, index) in outS33_failConnected" :key="index">
              <td v-for="(key_, index) in Object.keys(outS33_failConnected[0])" :key="index">{{row[key_]}}</td>
            </tr>
          </tbody>
          </table>
        </div>  
      </div>
    </div> 
</template>
<script>
import getOutput from '@/services/getOutput'
export default {
  data() {
    return {
      outS11: [
        {"col 1": '[row 1 col 1]', "col 2":'[row 1 col 2]', "col 3":'[row 1 col 3]', "col 4":'[row 1 col 4]'}
      ],
      outS12: [
        {"col 1": '[row 1 col 1]', "col 2":'[row 1 col 2]', "col 3":'[row 1 col 3]', "col 4":'[row 1 col 4]'}
      ],
      outS13: [
        {"col 1": '[row 1 col 1]', "col 2":'[row 1 col 2]', "col 3":'[row 1 col 3]', "col 4":'[row 1 col 4]'}
      ],
      outS14: [
        {"col 1": '[row 1 col 1]', "col 2":'[row 1 col 2]', "col 3":'[row 1 col 3]', "col 4":'[row 1 col 4]'}
      ],
      outS15: [
        {"col 1": '[row 1 col 1]', "col 2":'[row 1 col 2]', "col 3":'[row 1 col 3]', "col 4":'[row 1 col 4]'}
      ],
      outS16: [
        {"col 1": '[row 1 col 1]', "col 2":'[row 1 col 2]', "col 3":'[row 1 col 3]', "col 4":'[row 1 col 4]'}
      ],
      outS17: [
        {"col 1": '[row 1 col 1]', "col 2":'[row 1 col 2]', "col 3":'[row 1 col 3]', "col 4":'[row 1 col 4]'}
      ],
      outS18: "DMARC record data...",
      outS19: [
        {"col 1": '[row 1 col 1]', "col 2":'[row 1 col 2]', "col 3":'[row 1 col 3]', "col 4":'[row 1 col 4]'}
      ],
      outS110: [
        {"col 1": '[row 1 col 1]', "col 2":'[row 1 col 2]', "col 3":'[row 1 col 3]', "col 4":'[row 1 col 4]'}
      ],
      outS20: [
        {"col 1": '[row 1 col 1]', "col 2":'[row 1 col 2]', "col 3":'[row 1 col 3]', "col 4":'[row 1 col 4]'}
      ],
      outS31: [
        {"col 1": '[row 1 col 1]', "col 2":'[row 1 col 2]', "col 3":'[row 1 col 3]', "col 4":'[row 1 col 4]'}
      ],
      outS32: [
        {"col 1": '[row 1 col 1]', "col 2":'[row 1 col 2]', "col 3":'[row 1 col 3]', "col 4":'[row 1 col 4]'}
      ],
      outS33_dubiousFile: [
        {"col 1": '[row 1 col 1]', "col 2":'[row 1 col 2]', "col 3":'[row 1 col 3]', "col 4":'[row 1 col 4]'}
      ],
      outS33_failConnected: [
        {"col 1": '[row 1 col 1]', "col 2":'[row 1 col 2]', "col 3":'[row 1 col 3]', "col 4":'[row 1 col 4]'}
      ],
      entityName: '',
      searchDomain: '',
      keyword:'',
      mongoDB: {'password': 'jonathan', 'database': 'ClientData'}
    };
  },
  methods:{
    async getOutput(){
      this.loadingStatus = "Calling the APIs"
      const response = await getOutput.getOutput({
        entityName: this.entityName,
        searchDomain: this.searchDomain,
        keyword: this.keyword
      })
      this.outS11 = response.data['outS11']
      this.outS12 = response.data['outS12']
      this.outS13 = response.data['outS13']
      this.outS14 = response.data['outS14']
      this.outS15 = response.data['outS15']
      this.outS16 = response.data['outS16']
      this.outS17 = response.data['outS17']
      this.outS18 = response.data['outS18']
      this.outS19 = response.data['outS19']
      this.outS110 = response.data['outS110']
      this.outS20 = response.data['outS20']
      this.outS31 = response.data['outS31']
      this.outS32 = response.data['outS32']
      this.outS33_dubiousFile = response.data['outS33_dubiousFile']
      this.outS33_failConnected = response.data['outS33_failConnected']
      this.loadingStatus = "Done!"
    }
  }
}
</script>
<style>
.scroll{
  width:3000px;
  max-height:500px;
  overflow: scroll;
  margin-bottom: 20px;
}
table {
  font-family: 'Open Sans', sans-serif;
  width: 750px;
  border-collapse: collapse;
  border: 3px solid #44475C;
  overflow: scroll;
  margin: 10px 10px 0 10px;
}

table th {
  text-transform: uppercase;
  text-align: left;
  background: #44475C;
  color: #FFF;
  padding: 8px;
  min-width: 30px;
}

table td {
  text-align: left;
  padding: 8px;
  border-right: 2px solid #7D82A8;
}
table td:last-child {
  border-right: none;
}
table tbody tr:nth-child(2n) td {
  background: #D4D8F9;
}
</style>
